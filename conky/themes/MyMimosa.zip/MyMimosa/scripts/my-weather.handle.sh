#!/bin/bash

case $1 in
  CUR_TEMP)
    echo $(cat ~/.cache/my-weather.json | jq -r '.current.temperature_2m')
  ;;
  CUR_HUM)
    echo $(cat ~/.cache/my-weather.json | jq -r '.current.relative_humidity_2m')
  ;;
  CUR_WS)
    echo $(cat ~/.cache/my-weather.json | jq -r '.current.wind_speed_10m')
  ;;
  CUR_PREC)
    PRECIPITATION=$(cat ~/.cache/my-weather.json | jq -r '.current.precipitation')
    PROB_PRECIPITATION=$(cat ~/.cache/my-weather.json | jq -r '.daily.precipitation_probability_mean[0]')
    if [ "$PRECIPITATION" -eq "0" ];then
      echo "$PROB_PRECIPITATION %"
    else
      echo "$PRECIPITATION mm"
    fi
  ;;
  DAILY_DAY)
    echo $(cat ~/.cache/my-weather.json | jq -r '.daily.time['$2']' | awk -F- '{print $3}')
  ;;
  DAILY_MIN)
    echo $(cat ~/.cache/my-weather.json | jq -r '.daily.temperature_2m_min['$2']')
  ;;
  DAILY_MAX)
    echo $(cat ~/.cache/my-weather.json | jq -r '.daily.temperature_2m_max['$2']')
  ;;
esac